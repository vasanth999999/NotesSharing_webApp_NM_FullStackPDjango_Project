from django.apps import AppConfig


class NotFoundConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'not_found'
